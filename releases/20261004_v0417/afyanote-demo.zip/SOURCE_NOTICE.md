# AfyaNote local demonstration package · afyanote-v0.4.17

Prepared by ChatGPT / Codex. The app is joint Claude + ChatGPT/Codex work.
The unchanged 249,284-byte character-ngram classifier and original training were created by Claude.
Codex implemented disclosed review/export/offline/context repairs and generated these browser proofs.
The QR library retains Kazuhiko Arase's embedded copyright/license notice in app/vendor/qrcode.js.
Project LICENSE is included; external WHO source terms retain their source terms of use.
Qwen weights, MLX runtime, synthetic training corpora and original challenge PDFs are NOT shipped here.

Synthetic demonstration only. No clinical/native-language/physical-phone approval.
39 current browser checks, 29 deep checks including 60 layout combinations; actual reports included.
Media source manifest included; video is separately available in the working workspace.
No repository push, deployment, upload or live system integration has occurred through this tool.

For development: serve app/ locally, e.g. python3 -m http.server 8000 --directory app.
On a phone localhost refers to that phone. A reachable secure origin, initial cached load
and an actual airplane-mode/OS-restart test are separate requirements. Use fictional data.
Case information is in page memory only; explicit downloads/clipboard/QR leave that memory boundary.

README/model card document references are workspace references; not all referenced research,
training, reports and pitch assets are included in this deliberately bounded package.
